﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen2daEv
{
    
    public class Color
    {
        public double R;
        public double G;
        public double B;
        public double A;


    }
}
