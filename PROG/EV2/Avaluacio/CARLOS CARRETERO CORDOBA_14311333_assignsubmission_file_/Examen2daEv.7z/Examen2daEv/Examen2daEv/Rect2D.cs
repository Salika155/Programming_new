﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen2daEv
{
    public class Rect2D
    {
        

        private Point2D _xi;
        private Point2D _yi;
        private Point2D _xs;
        private Point2D _ys;

        public Rect2D(Point2D xi, Point2D yi, Point2D xs, Point2D ys)
        {
            _xi = xi;
            _yi = yi;
            _xs = xs;
            _ys = ys;
        }

        //public override void DrawRectangle()
        //{

        //}
    }
}
