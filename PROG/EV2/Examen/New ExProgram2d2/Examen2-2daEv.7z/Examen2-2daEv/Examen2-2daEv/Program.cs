﻿namespace Examen2_2daEv
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            

        }
    }
}