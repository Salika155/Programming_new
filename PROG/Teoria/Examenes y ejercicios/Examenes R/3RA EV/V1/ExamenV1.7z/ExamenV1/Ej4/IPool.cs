﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej4
{
    public interface IPool<T>
    {
        static void CreatePool(T pool)
        {
            //Pool<T> pool = new Pool<T>();
        }

        
    }
}
