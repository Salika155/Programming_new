﻿namespace Ej1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 5;

            Pruebas.GetFibonacci(n);    

            
        
        }
    }
}