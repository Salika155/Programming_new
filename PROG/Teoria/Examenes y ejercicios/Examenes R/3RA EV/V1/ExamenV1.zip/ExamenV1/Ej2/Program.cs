﻿namespace Ej2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 1, 7, 9, 12, 20 };
            int[] b = { 2, 3, 9 };
            //int[] c = { };

            Pruebas.Merge(a, b);
            
        }
    }
}