﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej4
{
    public class Pool<T> : IPool<T>
    {
        private int _count;

        public int Count {  get { return _count; } }


        private Pool()
        {

        }

        //public  GiveMe()
        

        

        //ToArray
        //Clone
        //Count
    }
}
