﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej5
{
    internal class CasillaGanadora : Casilla
    {
        public CasillaGanadora(int numero) : base(numero)
        {
            numero = 63;
        }
    }
}
