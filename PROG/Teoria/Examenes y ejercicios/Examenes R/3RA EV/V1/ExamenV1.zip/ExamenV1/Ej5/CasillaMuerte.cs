﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej5
{
    internal class CasillaMuerte : Casilla
    {
        public CasillaMuerte(int numero) : base(numero)
        {
        }
    }
}
