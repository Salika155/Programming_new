﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej5
{
    internal class JugadorRapido : Jugador
    {
        public JugadorRapido(string name, Dado dado) : base(name, dado)
        {
        }
    }
}
